package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CinematicColorScheme = darkColorScheme(
    primary = GoldAmberPrimary,
    onPrimary = Color(0xFF1E1400),
    primaryContainer = GoldAmberContainer,
    onPrimaryContainer = OnGoldAmberContainer,
    secondary = CyberCyanSecondary,
    onSecondary = Color(0xFF002024),
    secondaryContainer = CyberCyanContainer,
    onSecondaryContainer = OnCyberCyanContainer,
    tertiary = NeonVioletTertiary,
    onTertiary = Color(0xFF23003B),
    tertiaryContainer = NeonVioletContainer,
    onTertiaryContainer = Color(0xFFE9D5FF),
    background = CinematicBlack,
    onBackground = TextPrimary,
    surface = CinematicSurface,
    onSurface = TextPrimary,
    surfaceVariant = CinematicSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = CinematicBorderHigh,
    outlineVariant = CinematicCardBorder,
    error = DangerCrimson,
    onError = Color.White,
    errorContainer = DangerCrimsonContainer,
    onErrorContainer = Color(0xFFFFCDD2)
)

@Composable
fun FlowStoryboardTheme(
    darkTheme: Boolean = true, // Default to cinematic dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = CinematicColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = CinematicBlack.toArgb()
            window.navigationBarColor = CinematicBlack.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
