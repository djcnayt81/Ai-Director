package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CharacterEntity
import com.example.data.model.GenerationHistoryEntity
import com.example.data.model.LocationEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.SceneEntity
import com.example.data.model.ShotEntity
import com.example.data.model.TimelineClipEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    fun getProjectById(id: String): Flow<ProjectEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)
}

@Dao
interface CharacterDao {
    @Query("SELECT * FROM characters WHERE projectId = :projectId")
    fun getCharactersForProject(projectId: String): Flow<List<CharacterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacters(characters: List<CharacterEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacter(character: CharacterEntity)

    @Query("DELETE FROM characters WHERE id = :id")
    suspend fun deleteCharacter(id: String)
}

@Dao
interface LocationDao {
    @Query("SELECT * FROM locations WHERE projectId = :projectId")
    fun getLocationsForProject(projectId: String): Flow<List<LocationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocations(locations: List<LocationEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: LocationEntity)

    @Query("DELETE FROM locations WHERE id = :id")
    suspend fun deleteLocation(id: String)
}

@Dao
interface SceneDao {
    @Query("SELECT * FROM scenes WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getScenesForProject(projectId: String): Flow<List<SceneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScene(scene: SceneEntity)

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Query("DELETE FROM scenes WHERE id = :id")
    suspend fun deleteScene(id: String)
}

@Dao
interface ShotDao {
    @Query("SELECT * FROM shots WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getShotsForProject(projectId: String): Flow<List<ShotEntity>>

    @Query("SELECT * FROM shots WHERE sceneId = :sceneId ORDER BY orderIndex ASC")
    fun getShotsForScene(sceneId: String): Flow<List<ShotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShots(shots: List<ShotEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShot(shot: ShotEntity)

    @Update
    suspend fun updateShot(shot: ShotEntity)

    @Query("DELETE FROM shots WHERE id = :id")
    suspend fun deleteShot(id: String)
}

@Dao
interface TimelineDao {
    @Query("SELECT * FROM timeline_clips WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getClipsForProject(projectId: String): Flow<List<TimelineClipEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClips(clips: List<TimelineClipEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: TimelineClipEntity)

    @Update
    suspend fun updateClip(clip: TimelineClipEntity)

    @Query("DELETE FROM timeline_clips WHERE id = :id")
    suspend fun deleteClip(id: String)

    @Query("DELETE FROM timeline_clips WHERE projectId = :projectId")
    suspend fun clearTimeline(projectId: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM generation_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<GenerationHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: GenerationHistoryEntity)

    @Query("DELETE FROM generation_history WHERE id = :id")
    suspend fun deleteHistory(id: String)

    @Query("DELETE FROM generation_history")
    suspend fun clearHistory()
}
