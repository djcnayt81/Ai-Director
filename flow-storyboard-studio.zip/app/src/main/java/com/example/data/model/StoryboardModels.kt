package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class ProjectGenre(val displayName: String) {
    SCI_FI("Sci-Fi"),
    CYBERPUNK("Cyberpunk"),
    THRILLER("Thriller"),
    DRAMA("Drama"),
    ROMANCE("Romance"),
    ACTION("Action"),
    HORROR("Horror"),
    DOCUMENTARY("Documentary"),
    ANIMATION("Animation"),
    FANTASY("Fantasy")
}

enum class AspectRatioOption(val label: String, val ratio: Float, val dimensionText: String) {
    CINEMATIC_WIDESCREEN("2.39:1 Anamorphic", 2.39f, "3840x1608"),
    STANDARD_16_9("16:9 Cinema HD", 1.777f, "3840x2160"),
    VERTICAL_9_16("9:16 Mobile / Reel", 0.5625f, "2160x3840"),
    CLASSIC_4_3("4:3 Academy", 1.333f, "2880x2160"),
    SQUARE_1_1("1:1 Square", 1.0f, "2160x2160")
}

enum class ShotStatus {
    DRAFT,
    GENERATED,
    APPROVED,
    CONVERTED_TO_VIDEO
}

enum class ImageModelType(val modelName: String, val badge: String, val description: String) {
    NANO_BANANA_2("gemini-3.1-flash-image-preview", "Nano Banana 2", "Ultra-fast generation & prompt agility"),
    NANO_BANANA_PRO("gemini-3-pro-image-preview", "Nano Banana Pro", "High-fidelity professional 4K rendering & character lock"),
    FLASH_IMAGE("gemini-2.5-flash-image", "Flash Image 2.5", "Standard production storyboard frames")
}

enum class VideoModelType(val modelName: String, val badge: String, val description: String) {
    VEO_3_1("veo-3.1-generate-preview", "Veo 3.1", "High-end cinematic motion & photorealism"),
    VEO_3_1_FAST("veo-3.1-fast-generate-preview", "Veo 3.1 Fast", "Rapid dynamic motion rendering"),
    GEMINI_OMNI_FLASH("gemini-flash-latest", "Gemini Omni Flash", "Ultra-fast scene & camera motion generator")
}

enum class CameraAngle(val label: String) {
    EXTREME_WIDE("Extreme Wide Shot (EWS)"),
    WIDE_SHOT("Wide Shot (WS)"),
    MEDIUM_SHOT("Medium Shot (MS)"),
    MEDIUM_CLOSE_UP("Medium Close-Up (MCU)"),
    CLOSE_UP("Close-Up (CU)"),
    EXTREME_CLOSE_UP("Extreme Close-Up (ECU)"),
    LOW_ANGLE("Dramatic Low Angle"),
    HIGH_ANGLE("High Angle Overhead"),
    DUTCH_ANGLE("Dutch / Canted Angle"),
    OVER_THE_SHOULDER("Over-the-Shoulder (OTS)"),
    POV("Point of View (POV)")
}

enum class CameraMovement(val label: String) {
    STATIC("Static Hold"),
    SLOW_PAN_RIGHT("Slow Pan Right"),
    SLOW_PAN_LEFT("Slow Pan Left"),
    DOLLY_IN("Dolly In / Push"),
    DOLLY_OUT("Dolly Out / Pull"),
    CRANE_UP("Crane Up / Jib"),
    TRACKING_SHOT("Smooth Tracking"),
    ORBIT_360("Circular Orbit"),
    ZOOM_IN("Cinematic Zoom In"),
    WHIP_PAN("Dynamic Whip Pan")
}

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val logline: String = "",
    val synopsis: String = "",
    val genre: ProjectGenre = ProjectGenre.SCI_FI,
    val visualStyle: String = "Cinematic 35mm film grain, anamorphic lens flare, moody lighting",
    val aspectRatio: AspectRatioOption = AspectRatioOption.STANDARD_16_9,
    val targetDurationSeconds: Int = 180,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isCloudSynced: Boolean = true,
    val thumbnailPrompt: String = ""
)

@Entity(tableName = "characters")
data class CharacterEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val role: String = "Lead Protagonist",
    val visualDescription: String = "",
    val costumePrompt: String = "",
    val referenceImageUrl: String = "",
    val facialFeatures: String = "",
    val voiceProfile: String = "Warm baritone with subtle grit"
)

@Entity(tableName = "locations")
data class LocationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val settingType: String = "INT.", // INT. / EXT.
    val lightingMood: String = "Moody neon rim light with soft volumetric fog",
    val timeOfDay: String = "Night / Golden Hour",
    val visualDetails: String = "",
    val referenceImageUrl: String = ""
)

@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val sceneNumber: Int,
    val title: String,
    val heading: String = "EXT. CITY ROOFTOP - NIGHT",
    val locationId: String = "",
    val summary: String = "",
    val emotionalTone: String = "Tense & atmospheric",
    val timeOfDay: String = "Night",
    val orderIndex: Int = 0
)

@Entity(tableName = "shots")
data class ShotEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val sceneId: String,
    val projectId: String,
    val shotNumber: Int,
    val shotType: String = "Wide Shot",
    val cameraAngle: CameraAngle = CameraAngle.WIDE_SHOT,
    val cameraMovement: CameraMovement = CameraMovement.DOLLY_IN,
    val actionPrompt: String = "",
    val dialogue: String = "",
    val dialogueSpeaker: String = "",
    val sfxNotes: String = "",
    val bgmNotes: String = "",
    val durationSeconds: Float = 3.5f,
    val characterNames: String = "", // Comma-separated
    val generatedImageUrl: String = "",
    val videoClipUrl: String = "",
    val status: ShotStatus = ShotStatus.DRAFT,
    val continuityNotes: String = "",
    val motionPrompt: String = "Camera pushes forward smoothly, cinematic parallax motion",
    val lensFocalLength: String = "50mm f/1.4",
    val resolution: String = "4K Cinema",
    val orderIndex: Int = 0
)

@Entity(tableName = "timeline_clips")
data class TimelineClipEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val shotId: String = "",
    val trackType: String = "VIDEO", // VIDEO, DIALOGUE, SFX, MUSIC
    val title: String,
    val mediaUrl: String = "",
    val startSeconds: Float = 0f,
    val durationSeconds: Float = 3.5f,
    val volume: Float = 1.0f,
    val orderIndex: Int = 0
)

@Entity(tableName = "generation_history")
data class GenerationHistoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String = "",
    val type: String = "IMAGE", // IMAGE, VIDEO, SCRIPT, DIRECTOR
    val modelName: String,
    val prompt: String,
    val outputUrl: String = "",
    val outputText: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SUCCESS",
    val creditsUsed: Int = 2
)

data class ContinuityIssue(
    val shotId: String,
    val shotNumber: Int,
    val category: String, // "Costume", "Lighting", "Prop", "Time of Day", "Actor"
    val description: String,
    val suggestion: String,
    val severity: String = "WARNING" // "WARNING", "CRITICAL", "INFO"
)

data class AiDirectorRequest(
    val userInstruction: String, // e.g. "Make this scene more cinematic and romantic"
    val currentPrompt: String,
    val characterDetails: String,
    val locationDetails: String,
    val sceneTone: String
)

data class UserAccountState(
    val userId: String = "dir_7749",
    val name: String = "Elena Rostova",
    val email: String = "elena.rostova@cinemaflow.studio",
    val planName: String = "Pro Director Studio",
    val creditsRemaining: Int = 850,
    val totalGenerations: Int = 142,
    val isLoggedInWithGoogle: Boolean = true,
    val isCloudSyncActive: Boolean = true,
    val storageUsedGb: Float = 1.4f,
    val storageTotalGb: Float = 50.0f
)
