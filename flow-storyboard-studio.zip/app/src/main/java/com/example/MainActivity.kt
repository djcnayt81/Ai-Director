package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.CreateScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.StoryboardScreen
import com.example.ui.screens.TimelineScreen
import com.example.ui.theme.CinematicBlack
import com.example.ui.theme.CinematicBorderHigh
import com.example.ui.theme.CinematicSurface
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.FlowStoryboardTheme
import com.example.ui.theme.GoldAmberContainer
import com.example.ui.theme.GoldAmberPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.FlowStoryboardViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Studio", Icons.Default.Home)
    object Storyboard : Screen("storyboard", "Storyboard", Icons.Default.Movie)
    object Create : Screen("create", "New Film", Icons.Default.AddCircle)
    object Timeline : Screen("timeline", "Timeline", Icons.Default.Timeline)
    object Projects : Screen("projects", "Vault", Icons.Default.Folder)
    object Profile : Screen("profile", "Account", Icons.Default.Person)
}

class MainActivity : ComponentActivity() {

    private val viewModel: FlowStoryboardViewModel by viewModels {
        FlowStoryboardViewModel.provideFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FlowStoryboardTheme {
                FlowStoryboardApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun FlowStoryboardApp(viewModel: FlowStoryboardViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val navItems = listOf(
        Screen.Home,
        Screen.Storyboard,
        Screen.Create,
        Screen.Timeline,
        Screen.Projects,
        Screen.Profile
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = CinematicSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_navigation_bar")
            ) {
                navItems.forEach { screen ->
                    val selected = currentRoute == screen.route
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        selected = selected,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CinematicBlack,
                            selectedTextColor = GoldAmberPrimary,
                            indicatorColor = GoldAmberPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_${screen.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CinematicBlack)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.Create.route) },
                        onNavigateToStoryboard = { navController.navigate(Screen.Storyboard.route) },
                        onNavigateToTimeline = { navController.navigate(Screen.Timeline.route) },
                        onNavigateToProjects = { navController.navigate(Screen.Projects.route) },
                        onNavigateToProfile = { navController.navigate(Screen.Profile.route) }
                    )
                }
                composable(Screen.Storyboard.route) {
                    StoryboardScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.Create.route) },
                        onNavigateToTimeline = { navController.navigate(Screen.Timeline.route) }
                    )
                }
                composable(Screen.Create.route) {
                    CreateScreen(
                        viewModel = viewModel,
                        onFinishedCreation = { navController.navigate(Screen.Storyboard.route) }
                    )
                }
                composable(Screen.Timeline.route) {
                    TimelineScreen(
                        viewModel = viewModel
                    )
                }
                composable(Screen.Projects.route) {
                    ProjectsScreen(
                        viewModel = viewModel,
                        onNavigateToCreate = { navController.navigate(Screen.Create.route) },
                        onNavigateToStoryboard = { navController.navigate(Screen.Storyboard.route) }
                    )
                }
                composable(Screen.Profile.route) {
                    ProfileScreen(
                        viewModel = viewModel
                    )
                }
            }

            // Global floating status notification bar
            if (statusMessage != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CinematicSurface,
                    border = BorderStroke(1.dp, GoldAmberPrimary.copy(alpha = 0.8f)),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 12.dp, start = 16.dp, end = 16.dp)
                        .testTag("status_message_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = GoldAmberPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = statusMessage!!,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                LaunchedEffect(statusMessage) {
                    kotlinx.coroutines.delay(4000)
                    viewModel.clearStatusMessage()
                }
            }
        }
    }
}
