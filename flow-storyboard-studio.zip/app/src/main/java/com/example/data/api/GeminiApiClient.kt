package com.example.data.api

import com.example.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object GeminiApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"

    fun getApiKey(): String {
        val key = BuildConfig.GEMINI_API_KEY
        return if (key == "MY_GEMINI_API_KEY" || key.isBlank()) "" else key
    }

    suspend fun generateContent(
        modelName: String = "gemini-3.5-flash",
        prompt: String,
        systemInstruction: String? = null,
        temperature: Float = 0.7f
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("GEMINI_API_KEY is not configured. Please add your key in AI Studio Secrets panel."))
        }

        try {
            val url = "$BASE_URL$modelName:generateContent?key=$apiKey"
            val jsonBody = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().put("text", prompt))
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val genConfig = JSONObject().apply {
                    put("temperature", temperature)
                }
                put("generationConfig", genConfig)

                if (!systemInstruction.isNullOrBlank()) {
                    val sysInstructionObj = JSONObject().apply {
                        val partsArray = JSONArray()
                        partsArray.put(JSONObject().put("text", systemInstruction))
                        put("parts", partsArray)
                    }
                    put("systemInstruction", sysInstructionObj)
                }
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Gemini API Error (${response.code}): $responseString"))
            }

            val root = JSONObject(responseString)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text", "")
                    return@withContext Result.success(text)
                }
            }

            Result.failure(Exception("No content returned in response: $responseString"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateImageWithPrompt(
        modelName: String = "gemini-3.1-flash-image-preview",
        prompt: String,
        aspectRatio: String = "16:9",
        imageSize: String = "2K"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("GEMINI_API_KEY is not configured"))
        }

        try {
            val url = "$BASE_URL$modelName:generateContent?key=$apiKey"
            val jsonBody = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().put("text", prompt))
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val genConfig = JSONObject().apply {
                    val modalities = JSONArray().apply {
                        put("TEXT")
                        put("IMAGE")
                    }
                    put("responseModalities", modalities)
                    val imgConfig = JSONObject().apply {
                        put("aspectRatio", aspectRatio)
                        put("imageSize", imageSize)
                    }
                    put("imageConfig", imgConfig)
                }
                put("generationConfig", genConfig)
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(url).post(requestBody).build()
            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Image API Error: $responseString"))
            }

            val root = JSONObject(responseString)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val content = candidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val inlineData = part.optJSONObject("inlineData")
                        if (inlineData != null) {
                            val data = inlineData.optString("data")
                            val mime = inlineData.optString("mimeType", "image/png")
                            return@withContext Result.success("data:$mime;base64,$data")
                        }
                    }
                }
            }

            Result.failure(Exception("No image generated in response"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
