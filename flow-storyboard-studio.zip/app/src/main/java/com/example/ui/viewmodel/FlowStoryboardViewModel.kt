package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AspectRatioOption
import com.example.data.model.CameraAngle
import com.example.data.model.CameraMovement
import com.example.data.model.CharacterEntity
import com.example.data.model.ContinuityIssue
import com.example.data.model.GenerationHistoryEntity
import com.example.data.model.ImageModelType
import com.example.data.model.LocationEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectGenre
import com.example.data.model.SceneEntity
import com.example.data.model.ShotEntity
import com.example.data.model.ShotStatus
import com.example.data.model.TimelineClipEntity
import com.example.data.model.UserAccountState
import com.example.data.model.VideoModelType
import com.example.data.repository.StoryboardRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class FlowStoryboardViewModel(
    application: Application,
    private val repository: StoryboardRepository
) : AndroidViewModel(application) {

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedProjectId = MutableStateFlow("demo_project_cyberpunk")
    val selectedProjectId = _selectedProjectId.asStateFlow()

    val currentProject: StateFlow<ProjectEntity?> = _selectedProjectId.flatMapLatest { id ->
        if (id.isEmpty()) flowOf(null) else repository.getProject(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val scenes: StateFlow<List<SceneEntity>> = _selectedProjectId.flatMapLatest { id ->
        if (id.isEmpty()) flowOf(emptyList()) else repository.getScenes(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shots: StateFlow<List<ShotEntity>> = _selectedProjectId.flatMapLatest { id ->
        if (id.isEmpty()) flowOf(emptyList()) else repository.getShots(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val characters: StateFlow<List<CharacterEntity>> = _selectedProjectId.flatMapLatest { id ->
        if (id.isEmpty()) flowOf(emptyList()) else repository.getCharacters(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val locations: StateFlow<List<LocationEntity>> = _selectedProjectId.flatMapLatest { id ->
        if (id.isEmpty()) flowOf(emptyList()) else repository.getLocations(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val timelineClips: StateFlow<List<TimelineClipEntity>> = _selectedProjectId.flatMapLatest { id ->
        if (id.isEmpty()) flowOf(emptyList()) else repository.getTimelineClips(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val generationHistory: StateFlow<List<GenerationHistoryEntity>> = repository.generationHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userAccount: StateFlow<UserAccountState> = repository.userAccount

    private val _continuityIssues = MutableStateFlow<List<ContinuityIssue>>(emptyList())
    val continuityIssues = _continuityIssues.asStateFlow()

    private val _isAnalyzingStory = MutableStateFlow(false)
    val isAnalyzingStory = _isAnalyzingStory.asStateFlow()

    private val _isGeneratingImage = MutableStateFlow(false)
    val isGeneratingImage = _isGeneratingImage.asStateFlow()

    private val _isConvertingVideo = MutableStateFlow(false)
    val isConvertingVideo = _isConvertingVideo.asStateFlow()

    private val _isAiDirectorThinking = MutableStateFlow(false)
    val isAiDirectorThinking = _isAiDirectorThinking.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage = _statusMessage.asStateFlow()

    private val _activeShotForDetail = MutableStateFlow<ShotEntity?>(null)
    val activeShotForDetail = _activeShotForDetail.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialProjectIfEmpty()
            checkContinuity()
        }
    }

    fun selectProject(projectId: String) {
        _selectedProjectId.value = projectId
        checkContinuity()
    }

    fun setActiveShot(shot: ShotEntity?) {
        _activeShotForDetail.value = shot
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun createProject(
        title: String,
        genre: ProjectGenre,
        logline: String,
        synopsis: String,
        visualStyle: String,
        aspectRatio: AspectRatioOption,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            val newProject = ProjectEntity(
                title = title.ifBlank { "Untitled Masterpiece" },
                genre = genre,
                logline = logline,
                synopsis = synopsis,
                visualStyle = visualStyle.ifBlank { "35mm anamorphic, dramatic high contrast lighting" },
                aspectRatio = aspectRatio
            )
            repository.saveProject(newProject)
            _selectedProjectId.value = newProject.id
            _statusMessage.value = "Project created: ${newProject.title}"
            onCreated(newProject.id)
        }
    }

    fun startAiStoryAnalysis(
        storyText: String,
        genre: ProjectGenre,
        visualStyle: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isAnalyzingStory.value = true
            _statusMessage.value = "AI Director is breaking down screenplay, characters & shot lists..."
            try {
                val pId = _selectedProjectId.value
                val result = repository.analyzeStoryToFullProduction(
                    projectId = pId,
                    storyText = storyText,
                    genre = genre,
                    visualStyle = visualStyle
                )
                if (result.isSuccess) {
                    val (chars, locs, scenes) = result.getOrNull()!!
                    _statusMessage.value = "Generated ${chars.size} Characters, ${locs.size} Locations, ${scenes.size} Scenes!"
                    checkContinuity()
                    onComplete()
                } else {
                    _statusMessage.value = "Analysis finished with intelligent director preset."
                    onComplete()
                }
            } catch (e: Exception) {
                _statusMessage.value = "Error analyzing story: ${e.message}"
            } finally {
                _isAnalyzingStory.value = false
            }
        }
    }

    fun consultAiDirector(shot: ShotEntity, instruction: String, onUpdated: (ShotEntity) -> Unit) {
        viewModelScope.launch {
            _isAiDirectorThinking.value = true
            _statusMessage.value = "AI Director analyzing cinematic continuity..."
            try {
                val chars = characters.value.joinToString("; ") { "${it.name} (${it.costumePrompt})" }
                val locs = locations.value.joinToString("; ") { "${it.name} (${it.lightingMood})" }
                val result = repository.consultAiDirector(
                    shot = shot,
                    instruction = instruction,
                    characterContext = chars,
                    locationContext = locs
                )
                if (result.isSuccess) {
                    val updated = result.getOrNull()!!
                    _statusMessage.value = "AI Director updated shot prompt!"
                    _activeShotForDetail.value = updated
                    onUpdated(updated)
                }
            } catch (e: Exception) {
                _statusMessage.value = "AI Director error: ${e.message}"
            } finally {
                _isAiDirectorThinking.value = false
            }
        }
    }

    fun generateImageForShot(
        shot: ShotEntity,
        modelType: ImageModelType,
        resolution: String = "4K",
        references: List<String> = emptyList()
    ) {
        viewModelScope.launch {
            _isGeneratingImage.value = true
            _statusMessage.value = "Rendering shot frame with ${modelType.badge} ($resolution)..."
            try {
                val result = repository.generateShotImage(
                    shot = shot,
                    modelType = modelType,
                    resolution = resolution,
                    characterReferences = references
                )
                if (result.isSuccess) {
                    val updated = result.getOrNull()!!
                    _activeShotForDetail.value = updated
                    _statusMessage.value = "Shot #${shot.shotNumber} frame rendered in $resolution!"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Image render error: ${e.message}"
            } finally {
                _isGeneratingImage.value = false
            }
        }
    }

    fun convertShotToVideo(
        shot: ShotEntity,
        videoModel: VideoModelType,
        motionPrompt: String,
        cameraMovement: CameraMovement
    ) {
        viewModelScope.launch {
            _isConvertingVideo.value = true
            _statusMessage.value = "Converting frame to video with ${videoModel.badge}..."
            try {
                val result = repository.convertShotToVideo(
                    shot = shot,
                    videoModel = videoModel,
                    motionPrompt = motionPrompt,
                    cameraMovement = cameraMovement
                )
                if (result.isSuccess) {
                    val updated = result.getOrNull()!!
                    _activeShotForDetail.value = updated
                    _statusMessage.value = "Shot #${shot.shotNumber} converted to cinematic video!"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Video conversion error: ${e.message}"
            } finally {
                _isConvertingVideo.value = false
            }
        }
    }

    fun updateShotStatus(shot: ShotEntity, newStatus: ShotStatus) {
        viewModelScope.launch {
            val updated = shot.copy(status = newStatus)
            repository.saveShot(updated)
            _activeShotForDetail.value = updated
            _statusMessage.value = "Shot #${shot.shotNumber} marked as ${newStatus.name}"
        }
    }

    fun saveShotEdits(shot: ShotEntity) {
        viewModelScope.launch {
            repository.saveShot(shot)
            _activeShotForDetail.value = shot
            _statusMessage.value = "Shot #${shot.shotNumber} changes saved."
        }
    }

    fun checkContinuity() {
        viewModelScope.launch {
            val issues = repository.evaluateContinuity(_selectedProjectId.value)
            _continuityIssues.value = issues
        }
    }

    fun addCustomShot(sceneId: String) {
        viewModelScope.launch {
            val currentShots = shots.value
            val nextNum = (currentShots.maxOfOrNull { it.shotNumber } ?: 0) + 1
            val newShot = ShotEntity(
                sceneId = sceneId,
                projectId = _selectedProjectId.value,
                shotNumber = nextNum,
                shotType = "Medium Shot (MS)",
                cameraAngle = CameraAngle.MEDIUM_SHOT,
                cameraMovement = CameraMovement.STATIC,
                actionPrompt = "Cinematic frame with moody volumetric lighting and precise depth of field",
                durationSeconds = 3.5f,
                orderIndex = currentShots.size
            )
            repository.saveShot(newShot)
            _activeShotForDetail.value = newShot
            _statusMessage.value = "Added Shot #$nextNum"
        }
    }

    fun deleteShot(shotId: String) {
        viewModelScope.launch {
            repository.deleteShot(shotId)
            _activeShotForDetail.value = null
            _statusMessage.value = "Shot deleted."
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            val remaining = allProjects.value.filterNot { it.id == projectId }
            _selectedProjectId.value = remaining.firstOrNull()?.id ?: ""
            _statusMessage.value = "Project deleted."
        }
    }

    fun addTimelineClip(trackType: String, title: String, duration: Float) {
        viewModelScope.launch {
            val clips = timelineClips.value
            val lastEnd = clips.filter { it.trackType == trackType }.maxOfOrNull { it.startSeconds + it.durationSeconds } ?: 0f
            val newClip = TimelineClipEntity(
                projectId = _selectedProjectId.value,
                trackType = trackType,
                title = title,
                startSeconds = lastEnd,
                durationSeconds = duration,
                orderIndex = clips.size
            )
            repository.saveTimelineClip(newClip)
            _statusMessage.value = "Added $trackType clip to timeline"
        }
    }

    fun deleteTimelineClip(clipId: String) {
        viewModelScope.launch {
            repository.deleteTimelineClip(clipId)
        }
    }

    fun refillCredits(amount: Int) {
        repository.refillCredits(amount)
        _statusMessage.value = "Added $amount studio credits!"
    }

    fun toggleAuth(loginWithGoogle: Boolean) {
        repository.toggleAuth(loginWithGoogle)
        _statusMessage.value = if (loginWithGoogle) "Switched to Google Sign-In" else "Switched to Email Account"
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getDatabase(application)
                    val repo = StoryboardRepository(db)
                    return FlowStoryboardViewModel(application, repo) as T
                }
            }
    }
}
