package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CharacterEntity
import com.example.data.model.LocationEntity
import com.example.data.model.ProjectEntity
import com.example.ui.theme.CinematicBlack
import com.example.ui.theme.CinematicBorderHigh
import com.example.ui.theme.CinematicCardBorder
import com.example.ui.theme.CinematicSurface
import com.example.ui.theme.CinematicSurfaceVariant
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.GoldAmberContainer
import com.example.ui.theme.GoldAmberPrimary
import com.example.ui.theme.GoldAmberVariant
import com.example.ui.theme.NeonVioletContainer
import com.example.ui.theme.NeonVioletTertiary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.FlowStoryboardViewModel

@Composable
fun ProjectsScreen(
    viewModel: FlowStoryboardViewModel,
    onNavigateToCreate: () -> Unit,
    onNavigateToStoryboard: () -> Unit
) {
    val allProjects by viewModel.allProjects.collectAsStateWithLifecycle()
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val characters by viewModel.characters.collectAsStateWithLifecycle()
    val locations by viewModel.locations.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("PRODUCTIONS", "CHARACTERS", "LOCATIONS")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinematicBlack)
            .testTag("projects_screen_container"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CLOUD STUDIO VAULT",
                        color = GoldAmberPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "Projects, Characters & World Sets",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = onNavigateToCreate,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAmberPrimary, contentColor = CinematicBlack),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Film", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Sub Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = CinematicSurface,
                contentColor = GoldAmberPrimary,
                edgePadding = 20.dp,
                divider = {}
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    )
                }
            }
        }

        // Content
        when (selectedTab) {
            0 -> {
                // Productions
                items(allProjects) { project ->
                    val isSelected = project.id == currentProject?.id
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) CinematicSurfaceVariant else CinematicSurface),
                        border = BorderStroke(1.dp, if (isSelected) GoldAmberPrimary else CinematicCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp)
                            .clickable {
                                viewModel.selectProject(project.id)
                                onNavigateToStoryboard()
                            }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Folder, contentDescription = null, tint = GoldAmberPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = project.title,
                                        color = TextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .background(GoldAmberContainer, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "ACTIVE", color = GoldAmberPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = project.logline.ifBlank { "No logline specified." },
                                color = TextSecondary,
                                fontSize = 12.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${project.genre.displayName} • ${project.aspectRatio.label}",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                if (allProjects.size > 1) {
                                    IconButton(
                                        onClick = { viewModel.deleteProject(project.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = DangerCrimson.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Characters
                if (characters.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "No characters in active production", color = TextSecondary, fontSize = 13.sp)
                        }
                    }
                } else {
                    items(characters) { char ->
                        CharacterCard(character = char)
                    }
                }
            }

            2 -> {
                // Locations
                if (locations.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "No locations in active production", color = TextSecondary, fontSize = 13.sp)
                        }
                    }
                } else {
                    items(locations) { loc ->
                        LocationCard(location = loc)
                    }
                }
            }
        }
    }
}

@Composable
fun CharacterCard(character: CharacterEntity) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CinematicSurface),
        border = BorderStroke(1.dp, CinematicCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CyberCyanContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = CyberCyanSecondary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(text = character.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = character.role, color = CyberCyanSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "APPEARANCE:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text(text = character.visualDescription, color = TextSecondary, fontSize = 11.sp)

            if (character.costumePrompt.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "COSTUME / WARDROBE:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = character.costumePrompt, color = TextSecondary, fontSize = 11.sp)
            }

            if (character.voiceProfile.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "VOICE PROFILE:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = character.voiceProfile, color = GoldAmberVariant, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun LocationCard(location: LocationEntity) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CinematicSurface),
        border = BorderStroke(1.dp, CinematicCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(GoldAmberContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = GoldAmberPrimary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(text = location.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${location.settingType} • ${location.timeOfDay}", color = GoldAmberPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "LIGHTING & ATMOSPHERE:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text(text = location.lightingMood, color = TextSecondary, fontSize = 11.sp)

            if (location.visualDetails.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "GEOGRAPHY & DETAILS:", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = location.visualDetails, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}
