package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AspectRatioOption
import com.example.data.model.ProjectGenre
import com.example.ui.components.CreditPill
import com.example.ui.theme.CinematicBlack
import com.example.ui.theme.CinematicBorderHigh
import com.example.ui.theme.CinematicCardBorder
import com.example.ui.theme.CinematicSurface
import com.example.ui.theme.CinematicSurfaceVariant
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.GoldAmberContainer
import com.example.ui.theme.GoldAmberPrimary
import com.example.ui.theme.GoldAmberVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.FlowStoryboardViewModel

@Composable
fun CreateScreen(
    viewModel: FlowStoryboardViewModel,
    onFinishedCreation: () -> Unit
) {
    val userAccount by viewModel.userAccount.collectAsStateWithLifecycle()
    val isAnalyzingStory by viewModel.isAnalyzingStory.collectAsStateWithLifecycle()

    var projectTitle by remember { mutableStateOf("The Neon Horizon") }
    var logline by remember { mutableStateOf("An ex-pilot and an AI android race across an orbital station before atmospheric re-entry.") }
    var storyScript by remember {
        mutableStateOf(
            "EXT. ORBITAL FREIGHT DOCK - NIGHT\n" +
            "Siren alarms flash amber against the hull of the docking bay. RAFE (40s, rugged cyber-flight jacket) secures the magnetic airlock while KIRA (sleek synth-android with iridescent blue ocular circuits) decrypts the security mainframe.\n\n" +
            "RAFE: \"We have ninety seconds before the orbital defense drones triangulate our beacon!\"\n\n" +
            "KIRA: \"Telemetry indicates the containment vault is unlocked. Move now.\"\n\n" +
            "Rafe pushes into the vault corridor as emergency bulkhead doors begin sealing from above."
        )
    }

    var selectedGenre by remember { mutableStateOf(ProjectGenre.SCI_FI) }
    var selectedAspectRatio by remember { mutableStateOf(AspectRatioOption.STANDARD_16_9) }
    var visualStyle by remember { mutableStateOf("35mm anamorphic film grain, dramatic high-contrast cyan and amber neon lighting, volumetric mist") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinematicBlack)
            .testTag("create_screen_container"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NEW PRODUCTION",
                        color = GoldAmberPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "Story → AI Breakdown → Storyboard",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                CreditPill(credits = userAccount.creditsRemaining)
            }
        }

        // Script Sample Inspiration Pills
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "SAMPLE SCRIPT PRESETS:",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val presets = listOf(
                        Triple("Cyberpunk Heist", ProjectGenre.CYBERPUNK, "EXT. NEO-TOKYO METROPOLIS - RAIN\nA cyber-thief plugs into a floating data-cube as security androids rappel down glass skyscrapers."),
                        Triple("Deep Space Mystery", ProjectGenre.SCI_FI, "INT. DERELICT SPACESHIP - ZERO-G\nAstronaut Dr. Mercer floats into the silent cryogenic chamber. Only one pod is active, pulsing with an alien signal."),
                        Triple("Neon Noir Thriller", ProjectGenre.THRILLER, "EXT. DOCKSIDE WAREHOUSE - FOG\nDetective Cole lights a cigarette under flickering sodium lamps as footsteps echo in the wet mist behind him."),
                        Triple("Romantic Twilight", ProjectGenre.ROMANCE, "EXT. PARISIAN BRIDGETOP - SUNSET\nMira and Julian stand under golden hour amber light as violin music drifts across the river Seine.")
                    )
                    items(presets) { (name, genre, script) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CinematicSurfaceVariant,
                            border = BorderStroke(1.dp, CinematicCardBorder),
                            modifier = Modifier.clickable {
                                projectTitle = name
                                selectedGenre = genre
                                storyScript = script
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = GoldAmberPrimary, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = name, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        // Project Title & Logline
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, CinematicCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "PROJECT TITLE & LOGLINE", color = GoldAmberPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = projectTitle,
                        onValueChange = { projectTitle = it },
                        label = { Text("Production Title", color = TextMuted, fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAmberPrimary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("project_title_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = logline,
                        onValueChange = { logline = it },
                        label = { Text("Logline / Premise", color = TextMuted, fontSize = 12.sp) },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAmberPrimary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("project_logline_input")
                    )
                }
            }
        }

        // Story Screenplay Script Input
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, CinematicCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "STORY SCRIPT / SCENE TEXT", color = GoldAmberPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(text = "Formatted Screenplay", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = storyScript,
                        onValueChange = { storyScript = it },
                        placeholder = { Text("Write your story, script scene, or character dialogue here...", color = TextMuted, fontSize = 12.sp) },
                        minLines = 6,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAmberPrimary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("story_script_input")
                    )
                }
            }
        }

        // Genre & Aspect Ratio Selector
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, CinematicCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "GENRE & STYLE PRESET", color = GoldAmberPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ProjectGenre.values().toList()) { genre ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedGenre == genre) GoldAmberContainer else CinematicSurfaceVariant,
                                border = BorderStroke(1.dp, if (selectedGenre == genre) GoldAmberPrimary else CinematicCardBorder),
                                modifier = Modifier.clickable { selectedGenre = genre }
                            ) {
                                Text(
                                    text = genre.displayName,
                                    color = if (selectedGenre == genre) GoldAmberPrimary else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "CINEMATIC ASPECT RATIO", color = GoldAmberPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(AspectRatioOption.values().toList()) { ratio ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedAspectRatio == ratio) CyberCyanContainer else CinematicSurfaceVariant,
                                border = BorderStroke(1.dp, if (selectedAspectRatio == ratio) CyberCyanSecondary else CinematicCardBorder),
                                modifier = Modifier.clickable { selectedAspectRatio = ratio }
                            ) {
                                Text(
                                    text = ratio.label,
                                    color = if (selectedAspectRatio == ratio) CyberCyanSecondary else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Trigger Button
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Button(
                    onClick = {
                        viewModel.createProject(
                            title = projectTitle,
                            genre = selectedGenre,
                            logline = logline,
                            synopsis = storyScript,
                            visualStyle = visualStyle,
                            aspectRatio = selectedAspectRatio
                        ) {
                            viewModel.startAiStoryAnalysis(
                                storyText = storyScript,
                                genre = selectedGenre,
                                visualStyle = visualStyle
                            ) {
                                onFinishedCreation()
                            }
                        }
                    },
                    enabled = !isAnalyzingStory && storyScript.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAmberPrimary,
                        contentColor = CinematicBlack
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("create_production_button")
                ) {
                    if (isAnalyzingStory) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = CinematicBlack, strokeWidth = 2.5.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "AI Director Breaking Down Screenplay...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Generate AI Storyboard & Production (5 Credits)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}
