package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AspectRatioOption
import com.example.data.model.CameraAngle
import com.example.data.model.CameraMovement
import com.example.data.model.ShotEntity
import com.example.data.model.ShotStatus
import com.example.ui.theme.CinematicBlack
import com.example.ui.theme.CinematicBorderHigh
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardBorder
import com.example.ui.theme.CinematicSurface
import com.example.ui.theme.CinematicSurfaceVariant
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.GoldAmberContainer
import com.example.ui.theme.GoldAmberPrimary
import com.example.ui.theme.GoldAmberVariant
import com.example.ui.theme.NeonVioletTertiary
import com.example.ui.theme.OnGoldAmberContainer
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun CinematicShotPreviewFrame(
    shot: ShotEntity,
    aspectRatio: AspectRatioOption = AspectRatioOption.STANDARD_16_9,
    modifier: Modifier = Modifier,
    showControls: Boolean = true
) {
    val ratio = when (aspectRatio) {
        AspectRatioOption.CINEMATIC_WIDESCREEN -> 2.39f
        AspectRatioOption.STANDARD_16_9 -> 1.777f
        AspectRatioOption.VERTICAL_9_16 -> 0.5625f
        AspectRatioOption.CLASSIC_4_3 -> 1.333f
        AspectRatioOption.SQUARE_1_1 -> 1.0f
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CinematicBlack),
        border = BorderStroke(1.dp, CinematicCardBorder),
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
            .testTag("shot_preview_frame_${shot.shotNumber}")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (shot.generatedImageUrl.isNotBlank() && !shot.generatedImageUrl.startsWith("cinematic_frame://")) {
                AsyncImage(
                    model = shot.generatedImageUrl,
                    contentDescription = "Shot #${shot.shotNumber} frame",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Procedural Cinematic Canvas Rendering
                CinematicCanvasArt(
                    shotNumber = shot.shotNumber,
                    cameraAngle = shot.cameraAngle,
                    cameraMovement = shot.cameraMovement,
                    hasVideo = shot.status == ShotStatus.CONVERTED_TO_VIDEO
                )
            }

            // Top letterbox / film metadata overlay
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xCC0A0B10), Color.Transparent)
                        )
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(GoldAmberPrimary, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SHOT ${shot.shotNumber}",
                            color = CinematicBlack,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = shot.shotType,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                StatusPill(status = shot.status)
            }

            // Bottom camera & audio metadata overlay
            if (showControls) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xDD0A0B10))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = CyberCyanSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${shot.cameraAngle.name.take(12)} • ${shot.cameraMovement.label.take(14)}",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = "${shot.durationSeconds}s | ${shot.resolution}",
                        color = GoldAmberVariant,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Video indicator badge in center if converted to video
            if (shot.status == ShotStatus.CONVERTED_TO_VIDEO) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xAA00E5FF))
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Video Clip Ready",
                        tint = CinematicBlack,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CinematicCanvasArt(
    shotNumber: Int,
    cameraAngle: CameraAngle,
    cameraMovement: CameraMovement,
    hasVideo: Boolean
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Background Gradient based on shot number
        val baseColors = when (shotNumber % 4) {
            0 -> listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF311042))
            1 -> listOf(Color(0xFF0A192F), Color(0xFF0D2538), Color(0xFF134E4A))
            2 -> listOf(Color(0xFF1E120A), Color(0xFF2E190E), Color(0xFF451A03))
            else -> listOf(Color(0xFF1A1A2E), Color(0xFF16213E), Color(0xFF0F3460))
        }

        drawRect(
            brush = Brush.radialGradient(
                colors = baseColors,
                center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.5f),
                radius = w.coerceAtLeast(h)
            )
        )

        // Film grain / Cinematic framing lines
        // Anamorphic flare horizontal line
        val flareY = h * 0.45f
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    CyberCyanSecondary.copy(alpha = 0.6f),
                    GoldAmberPrimary.copy(alpha = 0.9f),
                    CyberCyanSecondary.copy(alpha = 0.6f),
                    Color.Transparent
                )
            ),
            start = androidx.compose.ui.geometry.Offset(0f, flareY),
            end = androidx.compose.ui.geometry.Offset(w, flareY),
            strokeWidth = 2.5f
        )

        // Composition Crosshairs / Rule of Thirds
        val thirdW = w / 3f
        val thirdH = h / 3f
        drawLine(Color(0x1AFFFFFF), androidx.compose.ui.geometry.Offset(thirdW, 0f), androidx.compose.ui.geometry.Offset(thirdW, h), 1f)
        drawLine(Color(0x1AFFFFFF), androidx.compose.ui.geometry.Offset(thirdW * 2, 0f), androidx.compose.ui.geometry.Offset(thirdW * 2, h), 1f)
        drawLine(Color(0x1AFFFFFF), androidx.compose.ui.geometry.Offset(0f, thirdH), androidx.compose.ui.geometry.Offset(w, thirdH), 1f)
        drawLine(Color(0x1AFFFFFF), androidx.compose.ui.geometry.Offset(0f, thirdH * 2), androidx.compose.ui.geometry.Offset(w, thirdH * 2), 1f)

        // Geometric stylized cinematic silhouette
        val silhouettePath = Path().apply {
            moveTo(w * 0.42f, h * 0.85f)
            lineTo(w * 0.46f, h * 0.48f)
            lineTo(w * 0.48f, h * 0.38f)
            lineTo(w * 0.52f, h * 0.38f)
            lineTo(w * 0.54f, h * 0.48f)
            lineTo(w * 0.58f, h * 0.85f)
            close()
        }
        drawPath(
            path = silhouettePath,
            color = Color(0xCC090A10)
        )
    }
}

@Composable
fun StatusPill(status: ShotStatus) {
    val (bgColor, textColor, label) = when (status) {
        ShotStatus.DRAFT -> Triple(CinematicSurfaceVariant, TextMuted, "DRAFT")
        ShotStatus.GENERATED -> Triple(GoldAmberContainer, OnGoldAmberContainer, "FRAME READY")
        ShotStatus.APPROVED -> Triple(SuccessGreen.copy(alpha = 0.2f), SuccessGreen, "APPROVED")
        ShotStatus.CONVERTED_TO_VIDEO -> Triple(CyberCyanContainer, CyberCyanSecondary, "VEO VIDEO")
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .border(1.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun CreditPill(
    credits: Int,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = CinematicSurfaceVariant,
        border = BorderStroke(1.dp, GoldAmberPrimary.copy(alpha = 0.5f)),
        modifier = modifier.testTag("credits_badge")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = GoldAmberPrimary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$credits CREDITS",
                color = GoldAmberPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun ContinuityBadge(
    issueCount: Int,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (issueCount > 0) WarningAmber.copy(alpha = 0.15f) else SuccessGreen.copy(alpha = 0.15f),
        border = BorderStroke(1.dp, if (issueCount > 0) WarningAmber else SuccessGreen),
        modifier = modifier.testTag("continuity_badge")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (issueCount > 0) Icons.Default.Warning else Icons.Default.CheckCircle,
                contentDescription = null,
                tint = if (issueCount > 0) WarningAmber else SuccessGreen,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (issueCount > 0) "$issueCount CONTINUITY" else "CONTINUITY OK",
                color = if (issueCount > 0) WarningAmber else SuccessGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
