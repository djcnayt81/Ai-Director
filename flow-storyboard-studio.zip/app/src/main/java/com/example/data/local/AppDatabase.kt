package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.model.AspectRatioOption
import com.example.data.model.CameraAngle
import com.example.data.model.CameraMovement
import com.example.data.model.CharacterEntity
import com.example.data.model.GenerationHistoryEntity
import com.example.data.model.LocationEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectGenre
import com.example.data.model.SceneEntity
import com.example.data.model.ShotEntity
import com.example.data.model.ShotStatus
import com.example.data.model.TimelineClipEntity

class Converters {
    @TypeConverter
    fun fromGenre(value: ProjectGenre): String = value.name

    @TypeConverter
    fun toGenre(value: String): ProjectGenre = try {
        ProjectGenre.valueOf(value)
    } catch (e: Exception) {
        ProjectGenre.SCI_FI
    }

    @TypeConverter
    fun fromAspectRatio(value: AspectRatioOption): String = value.name

    @TypeConverter
    fun toAspectRatio(value: String): AspectRatioOption = try {
        AspectRatioOption.valueOf(value)
    } catch (e: Exception) {
        AspectRatioOption.STANDARD_16_9
    }

    @TypeConverter
    fun fromShotStatus(value: ShotStatus): String = value.name

    @TypeConverter
    fun toShotStatus(value: String): ShotStatus = try {
        ShotStatus.valueOf(value)
    } catch (e: Exception) {
        ShotStatus.DRAFT
    }

    @TypeConverter
    fun fromCameraAngle(value: CameraAngle): String = value.name

    @TypeConverter
    fun toCameraAngle(value: String): CameraAngle = try {
        CameraAngle.valueOf(value)
    } catch (e: Exception) {
        CameraAngle.WIDE_SHOT
    }

    @TypeConverter
    fun fromCameraMovement(value: CameraMovement): String = value.name

    @TypeConverter
    fun toCameraMovement(value: String): CameraMovement = try {
        CameraMovement.valueOf(value)
    } catch (e: Exception) {
        CameraMovement.STATIC
    }
}

@Database(
    entities = [
        ProjectEntity::class,
        CharacterEntity::class,
        LocationEntity::class,
        SceneEntity::class,
        ShotEntity::class,
        TimelineClipEntity::class,
        GenerationHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun characterDao(): CharacterDao
    abstract fun locationDao(): LocationDao
    abstract fun sceneDao(): SceneDao
    abstract fun shotDao(): ShotDao
    abstract fun timelineDao(): TimelineDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "flow_storyboard_studio.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
