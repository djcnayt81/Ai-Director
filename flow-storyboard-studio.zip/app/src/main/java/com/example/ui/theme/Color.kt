package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Obsidian & OLED Dark Palette
val CinematicBlack = Color(0xFF0A0B10)
val CinematicSurface = Color(0xFF13151F)
val CinematicSurfaceVariant = Color(0xFF1B1E2E)
val CinematicCard = Color(0xFF181B27)
val CinematicCardBorder = Color(0xFF282C40)
val CinematicBorderHigh = Color(0xFF3B405A)

// Accent Colors
val GoldAmberPrimary = Color(0xFFFFB300)
val GoldAmberVariant = Color(0xFFFFC107)
val GoldAmberContainer = Color(0xFF332300)
val OnGoldAmberContainer = Color(0xFFFFE082)

val CyberCyanSecondary = Color(0xFF00E5FF)
val CyberCyanContainer = Color(0xFF00363D)
val OnCyberCyanContainer = Color(0xFF80F2FF)

val NeonVioletTertiary = Color(0xFFA855F7)
val NeonVioletContainer = Color(0xFF30104E)

val SuccessGreen = Color(0xFF10B981)
val SuccessGreenContainer = Color(0xFF043323)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberContainer = Color(0xFF451A03)
val DangerCrimson = Color(0xFFEF4444)
val DangerCrimsonContainer = Color(0xFF3F0B0B)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
