package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TimelineClipEntity
import com.example.ui.components.CinematicCanvasArt
import com.example.ui.components.CinematicShotPreviewFrame
import com.example.ui.theme.CinematicBlack
import com.example.ui.theme.CinematicBorderHigh
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardBorder
import com.example.ui.theme.CinematicSurface
import com.example.ui.theme.CinematicSurfaceVariant
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.GoldAmberContainer
import com.example.ui.theme.GoldAmberPrimary
import com.example.ui.theme.GoldAmberVariant
import com.example.ui.theme.NeonVioletContainer
import com.example.ui.theme.NeonVioletTertiary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.FlowStoryboardViewModel
import kotlinx.coroutines.delay

@Composable
fun TimelineScreen(
    viewModel: FlowStoryboardViewModel
) {
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val shots by viewModel.shots.collectAsStateWithLifecycle()
    val timelineClips by viewModel.timelineClips.collectAsStateWithLifecycle()

    var isPlaying by remember { mutableStateOf(false) }
    var currentPlayheadSeconds by remember { mutableFloatStateOf(0f) }
    var showAddTrackModal by remember { mutableStateOf(false) }
    var isExportingFilm by remember { mutableStateOf(false) }
    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }

    val totalDuration = remember(timelineClips, shots) {
        val clipEnd = timelineClips.maxOfOrNull { it.startSeconds + it.durationSeconds } ?: 0f
        val shotSum = shots.sumOf { it.durationSeconds.toDouble() }.toFloat()
        maxOf(15.0f, maxOf(clipEnd, shotSum))
    }

    // Playback loop simulation
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(100)
            currentPlayheadSeconds += 0.1f
            if (currentPlayheadSeconds >= totalDuration) {
                currentPlayheadSeconds = 0f
                isPlaying = false
            }
        }
    }

    // Identify which shot matches current playhead
    var accumulatedTime = 0f
    var currentActiveShot = shots.firstOrNull()
    for (s in shots) {
        if (currentPlayheadSeconds >= accumulatedTime && currentPlayheadSeconds <= (accumulatedTime + s.durationSeconds)) {
            currentActiveShot = s
            break
        }
        accumulatedTime += s.durationSeconds
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CinematicBlack)
            .testTag("timeline_screen_container"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TIMELINE STUDIO",
                        color = GoldAmberPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "${currentProject?.title ?: "Film"} • Final Cut Multi-Track",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = {
                        isExportingFilm = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAmberPrimary, contentColor = CinematicBlack),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("export_master_button")
                ) {
                    Text(text = "Render Film", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Live Playback Canvas Preview
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, CinematicCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (currentActiveShot != null) {
                        CinematicShotPreviewFrame(
                            shot = currentActiveShot,
                            aspectRatio = currentProject?.aspectRatio ?: com.example.data.model.AspectRatioOption.STANDARD_16_9,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(CinematicBlack, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Add shots to preview timeline reel", color = TextSecondary, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Player Scrub Controls & Timecode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val mins = (currentPlayheadSeconds / 60).toInt()
                        val secs = (currentPlayheadSeconds % 60).toInt()
                        val frames = ((currentPlayheadSeconds % 1) * 24).toInt()
                        Text(
                            text = String.format("TC: %02d:%02d:%02d", mins, secs, frames),
                            color = CyberCyanSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { currentPlayheadSeconds = (currentPlayheadSeconds - 2.0f).coerceAtLeast(0f) }) {
                                Icon(imageVector = Icons.Default.FastRewind, contentDescription = "Rewind", tint = TextPrimary)
                            }
                            IconButton(
                                onClick = { isPlaying = !isPlaying },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(GoldAmberPrimary)
                                    .testTag("timeline_play_pause_button")
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = CinematicBlack
                                )
                            }
                            IconButton(onClick = { currentPlayheadSeconds = (currentPlayheadSeconds + 2.0f).coerceAtMost(totalDuration) }) {
                                Icon(imageVector = Icons.Default.FastForward, contentDescription = "Forward", tint = TextPrimary)
                            }
                        }

                        val totMins = (totalDuration / 60).toInt()
                        val totSecs = (totalDuration % 60).toInt()
                        Text(
                            text = String.format("END: %02d:%02d:00", totMins, totSecs),
                            color = TextMuted,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Slider(
                        value = currentPlayheadSeconds,
                        onValueChange = { currentPlayheadSeconds = it },
                        valueRange = 0f..totalDuration,
                        colors = SliderDefaults.colors(
                            thumbColor = GoldAmberPrimary,
                            activeTrackColor = GoldAmberPrimary,
                            inactiveTrackColor = CinematicCardBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("timeline_playhead_slider")
                    )
                }
            }
        }

        // Multi-Track Timeline Lanes
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PRODUCTION TRACKS",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "+ Add Track",
                    color = GoldAmberPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { showAddTrackModal = true }
                )
            }
        }

        // 1. VIDEO TRACK
        item {
            TimelineLaneCard(
                trackName = "VIDEO TRACK (V1)",
                trackIcon = Icons.Default.Videocam,
                trackColor = CyberCyanSecondary,
                clips = timelineClips.filter { it.trackType == "VIDEO" },
                onDeleteClip = { viewModel.deleteTimelineClip(it) }
            )
        }

        // 2. DIALOGUE TRACK
        item {
            TimelineLaneCard(
                trackName = "DIALOGUE (A1)",
                trackIcon = Icons.Default.RecordVoiceOver,
                trackColor = GoldAmberPrimary,
                clips = timelineClips.filter { it.trackType == "DIALOGUE" },
                onDeleteClip = { viewModel.deleteTimelineClip(it) }
            )
        }

        // 3. SFX TRACK
        item {
            TimelineLaneCard(
                trackName = "SOUND FX (A2)",
                trackIcon = Icons.Default.VolumeUp,
                trackColor = SuccessGreen,
                clips = timelineClips.filter { it.trackType == "SFX" },
                onDeleteClip = { viewModel.deleteTimelineClip(it) }
            )
        }

        // 4. MUSIC TRACK
        item {
            TimelineLaneCard(
                trackName = "MUSIC / BGM (A3)",
                trackIcon = Icons.Default.MusicNote,
                trackColor = NeonVioletTertiary,
                clips = timelineClips.filter { it.trackType == "MUSIC" },
                onDeleteClip = { viewModel.deleteTimelineClip(it) }
            )
        }
    }

    if (showAddTrackModal) {
        AddTrackModal(
            onDismiss = { showAddTrackModal = false },
            onAdd = { trackType, title, duration ->
                viewModel.addTimelineClip(trackType, title, duration)
                showAddTrackModal = false
            }
        )
    }

    if (isExportingFilm) {
        RenderFilmDialog(
            projectTitle = currentProject?.title ?: "Film Production",
            onDismiss = { isExportingFilm = false }
        )
    }
}

@Composable
fun TimelineLaneCard(
    trackName: String,
    trackIcon: androidx.compose.ui.graphics.vector.ImageVector,
    trackColor: Color,
    clips: List<TimelineClipEntity>,
    onDeleteClip: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CinematicSurface),
        border = BorderStroke(1.dp, CinematicCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = trackIcon, contentDescription = null, tint = trackColor, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = trackName,
                    color = trackColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (clips.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .background(CinematicBlack, RoundedCornerShape(6.dp))
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(text = "Empty track lane", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                } else {
                    clips.forEach { clip ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = trackColor.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, trackColor.copy(alpha = 0.5f)),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = clip.title,
                                        color = TextPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${clip.startSeconds}s - ${String.format("%.1f", clip.startSeconds + clip.durationSeconds)}s",
                                        color = TextSecondary,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = TextMuted,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clickable { onDeleteClip(clip.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddTrackModal(
    onDismiss: () -> Unit,
    onAdd: (String, String, Float) -> Unit
) {
    var selectedType by remember { mutableStateOf("SFX") }
    var title by remember { mutableStateOf("Cybernetic Siren Ambient") }
    var duration by remember { mutableFloatStateOf(4.0f) }

    Surface(
        color = Color(0x99000000),
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, GoldAmberPrimary),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .clickable(enabled = false) {}
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(text = "ADD TIMELINE AUDIO / FX CLIP", color = GoldAmberPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("DIALOGUE", "SFX", "MUSIC").forEach { type ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedType == type) GoldAmberContainer else CinematicSurfaceVariant,
                                border = BorderStroke(1.dp, if (selectedType == type) GoldAmberPrimary else CinematicCardBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedType = type }
                            ) {
                                Text(
                                    text = type,
                                    color = if (selectedType == type) GoldAmberPrimary else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Clip Title / Notes", color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAmberPrimary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "DURATION: ${String.format("%.1f", duration)}s", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Slider(
                        value = duration,
                        onValueChange = { duration = it },
                        valueRange = 1f..15f,
                        colors = SliderDefaults.colors(thumbColor = GoldAmberPrimary, activeTrackColor = GoldAmberPrimary)
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { onAdd(selectedType, title, duration) },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAmberPrimary, contentColor = CinematicBlack),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add to Track", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun RenderFilmDialog(
    projectTitle: String,
    onDismiss: () -> Unit
) {
    var renderProgress by remember { mutableFloatStateOf(0f) }
    var isDone by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (renderProgress < 1.0f) {
            delay(150)
            renderProgress += 0.08f
        }
        renderProgress = 1.0f
        isDone = true
    }

    Surface(
        color = Color(0x99000000),
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, GoldAmberPrimary),
                modifier = Modifier.fillMaxWidth(0.88f)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = GoldAmberPrimary, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (!isDone) "STITCHING MASTER REEL" else "PRODUCTION RENDERED!",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (!isDone) "Encoding Veo 3.1 video frames and multi-track audio..." else "Master export ready for 4K ProRes playback & sharing.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (!isDone) {
                        CircularProgressIndicator(
                            progress = { renderProgress },
                            color = GoldAmberPrimary,
                            trackColor = CinematicCardBorder,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${(renderProgress * 100).toInt()}%",
                            color = GoldAmberPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = GoldAmberPrimary, contentColor = CinematicBlack),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Done & Return", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
