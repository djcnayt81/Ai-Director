package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CameraAngle
import com.example.data.model.CameraMovement
import com.example.data.model.ContinuityIssue
import com.example.data.model.ImageModelType
import com.example.data.model.ShotEntity
import com.example.data.model.ShotStatus
import com.example.data.model.VideoModelType
import com.example.ui.components.CinematicShotPreviewFrame
import com.example.ui.components.ContinuityBadge
import com.example.ui.components.CreditPill
import com.example.ui.components.StatusPill
import com.example.ui.theme.CinematicBlack
import com.example.ui.theme.CinematicBorderHigh
import com.example.ui.theme.CinematicCard
import com.example.ui.theme.CinematicCardBorder
import com.example.ui.theme.CinematicSurface
import com.example.ui.theme.CinematicSurfaceVariant
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.GoldAmberContainer
import com.example.ui.theme.GoldAmberPrimary
import com.example.ui.theme.GoldAmberVariant
import com.example.ui.theme.NeonVioletContainer
import com.example.ui.theme.NeonVioletTertiary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.FlowStoryboardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryboardScreen(
    viewModel: FlowStoryboardViewModel,
    onNavigateToCreate: () -> Unit,
    onNavigateToTimeline: () -> Unit
) {
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val scenes by viewModel.scenes.collectAsStateWithLifecycle()
    val shots by viewModel.shots.collectAsStateWithLifecycle()
    val characters by viewModel.characters.collectAsStateWithLifecycle()
    val continuityIssues by viewModel.continuityIssues.collectAsStateWithLifecycle()
    val activeShot by viewModel.activeShotForDetail.collectAsStateWithLifecycle()
    val userAccount by viewModel.userAccount.collectAsStateWithLifecycle()

    val isGeneratingImage by viewModel.isGeneratingImage.collectAsStateWithLifecycle()
    val isConvertingVideo by viewModel.isConvertingVideo.collectAsStateWithLifecycle()
    val isAiDirectorThinking by viewModel.isAiDirectorThinking.collectAsStateWithLifecycle()

    var selectedSceneIndex by remember { mutableIntStateOf(0) }
    var showContinuitySheet by remember { mutableStateOf(false) }
    var showAiDirectorDialog by remember { mutableStateOf(false) }
    var showImageGenModal by remember { mutableStateOf(false) }
    var showVideoGenModal by remember { mutableStateOf(false) }
    var showEditShotModal by remember { mutableStateOf(false) }

    val currentScene = scenes.getOrNull(selectedSceneIndex)
    val filteredShots = if (currentScene != null) {
        shots.filter { it.sceneId == currentScene.id }
    } else {
        shots
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CinematicBlack)
            .testTag("storyboard_screen_container")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Header Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "STORYBOARD STUDIO",
                            color = GoldAmberPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = currentProject?.title ?: "No Project",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ContinuityBadge(
                            issueCount = continuityIssues.size,
                            onClick = { showContinuitySheet = true }
                        )
                    }
                }
            }

            // Scene Tabs
            item {
                if (scenes.isNotEmpty()) {
                    ScrollableTabRow(
                        selectedTabIndex = selectedSceneIndex.coerceIn(0, scenes.size - 1),
                        containerColor = CinematicSurface,
                        contentColor = GoldAmberPrimary,
                        edgePadding = 20.dp,
                        divider = {}
                    ) {
                        scenes.forEachIndexed { index, scene ->
                            Tab(
                                selected = selectedSceneIndex == index,
                                onClick = { selectedSceneIndex = index },
                                text = {
                                    Text(
                                        text = "SCENE ${scene.sceneNumber}: ${scene.title}",
                                        fontSize = 12.sp,
                                        fontWeight = if (selectedSceneIndex == index) FontWeight.Bold else FontWeight.Normal,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Scene Context Header
            item {
                if (currentScene != null) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CinematicSurfaceVariant),
                        border = BorderStroke(1.dp, CinematicCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentScene.heading,
                                    color = GoldAmberVariant,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Box(
                                    modifier = Modifier
                                        .background(CinematicBlack, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = currentScene.emotionalTone,
                                        color = CyberCyanSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                            if (currentScene.summary.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentScene.summary,
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // Shot Cards List
            if (filteredShots.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "No shots in this scene yet", color = TextSecondary, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    currentScene?.let { viewModel.addCustomShot(it.id) }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAmberPrimary, contentColor = CinematicBlack)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Add Shot", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(filteredShots) { shot ->
                    StoryboardShotCard(
                        shot = shot,
                        onSelectShot = {
                            viewModel.setActiveShot(shot)
                        },
                        onOpenAiDirector = {
                            viewModel.setActiveShot(shot)
                            showAiDirectorDialog = true
                        },
                        onGenerateImage = {
                            viewModel.setActiveShot(shot)
                            showImageGenModal = true
                        },
                        onConvertToVideo = {
                            viewModel.setActiveShot(shot)
                            showVideoGenModal = true
                        },
                        onEditShot = {
                            viewModel.setActiveShot(shot)
                            showEditShotModal = true
                        },
                        onApprove = {
                            viewModel.updateShotStatus(shot, ShotStatus.APPROVED)
                        }
                    )
                }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        OutlinedButton(
                            onClick = {
                                currentScene?.let { viewModel.addCustomShot(it.id) }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldAmberPrimary),
                            border = BorderStroke(1.dp, GoldAmberPrimary.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Shot to Scene", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Modals & Bottom Sheets
        if (showContinuitySheet) {
            ModalBottomSheet(
                onDismissRequest = { showContinuitySheet = false },
                containerColor = CinematicSurface,
                dragHandle = null
            ) {
                ContinuitySheetContent(
                    issues = continuityIssues,
                    onClose = { showContinuitySheet = false }
                )
            }
        }

        if (showAiDirectorDialog && activeShot != null) {
            AiDirectorDialogModal(
                shot = activeShot!!,
                isThinking = isAiDirectorThinking,
                onDismiss = { showAiDirectorDialog = false },
                onConsult = { instruction ->
                    viewModel.consultAiDirector(activeShot!!, instruction) {
                        showAiDirectorDialog = false
                    }
                }
            )
        }

        if (showImageGenModal && activeShot != null) {
            ImageGeneratorModal(
                shot = activeShot!!,
                isGenerating = isGeneratingImage,
                onDismiss = { showImageGenModal = false },
                onGenerate = { model, res, refs ->
                    viewModel.generateImageForShot(activeShot!!, model, res, refs)
                    showImageGenModal = false
                }
            )
        }

        if (showVideoGenModal && activeShot != null) {
            VideoGeneratorModal(
                shot = activeShot!!,
                isConverting = isConvertingVideo,
                onDismiss = { showVideoGenModal = false },
                onConvert = { model, motionPrompt, move ->
                    viewModel.convertShotToVideo(activeShot!!, model, motionPrompt, move)
                    showVideoGenModal = false
                }
            )
        }

        if (showEditShotModal && activeShot != null) {
            EditShotModal(
                shot = activeShot!!,
                onDismiss = { showEditShotModal = false },
                onSave = { updated ->
                    viewModel.saveShotEdits(updated)
                    showEditShotModal = false
                },
                onDelete = {
                    viewModel.deleteShot(activeShot!!.id)
                    showEditShotModal = false
                }
            )
        }
    }
}

@Composable
fun StoryboardShotCard(
    shot: ShotEntity,
    onSelectShot: () -> Unit,
    onOpenAiDirector: () -> Unit,
    onGenerateImage: () -> Unit,
    onConvertToVideo: () -> Unit,
    onEditShot: () -> Unit,
    onApprove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CinematicSurface),
        border = BorderStroke(1.dp, CinematicCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .testTag("storyboard_shot_card_${shot.shotNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Visual Frame Preview
            CinematicShotPreviewFrame(
                shot = shot,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectShot() }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action prompt
            Text(
                text = "ACTION PROMPT",
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = shot.actionPrompt,
                color = TextPrimary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            // Dialogue if present
            if (shot.dialogue.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CinematicBlack, RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (shot.dialogueSpeaker.isNotBlank()) "${shot.dialogueSpeaker}: " else "DIALOGUE: ",
                        color = GoldAmberPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "\"${shot.dialogue}\"",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Audio & SFX notes
            if (shot.sfxNotes.isNotBlank() || shot.bgmNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${shot.sfxNotes} ${if (shot.bgmNotes.isNotBlank()) "• ${shot.bgmNotes}" else ""}",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Toolbar (Generate, AI Director, Convert to Video, Approve, Edit)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Generate Frame Button
                Button(
                    onClick = onGenerateImage,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAmberContainer,
                        contentColor = GoldAmberPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .height(38.dp)
                        .testTag("generate_image_button_${shot.shotNumber}")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Render", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // AI Director Button
                Button(
                    onClick = onOpenAiDirector,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyanContainer,
                        contentColor = CyberCyanSecondary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(38.dp)
                        .testTag("ai_director_button_${shot.shotNumber}")
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AI Director", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Convert to Video Button
                Button(
                    onClick = onConvertToVideo,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonVioletContainer,
                        contentColor = Color(0xFFE9D5FF)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .height(38.dp)
                        .testTag("convert_video_button_${shot.shotNumber}")
                ) {
                    Icon(imageVector = Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Veo Video", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Edit Button
                IconButton(
                    onClick = onEditShot,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CinematicSurfaceVariant)
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Shot", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }

                // Approve Button
                IconButton(
                    onClick = onApprove,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (shot.status == ShotStatus.APPROVED) SuccessGreen else CinematicSurfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Approve",
                        tint = if (shot.status == ShotStatus.APPROVED) CinematicBlack else SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ContinuitySheetContent(
    issues: List<ContinuityIssue>,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .testTag("continuity_sheet_content")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = WarningAmber)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CONTINUITY ENGINE",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            IconButton(onClick = onClose) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Tracking Character faces, Wardrobe, Lighting, Props, and Time across scenes to avoid filmmaking mistakes.",
            color = TextSecondary,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (issues.isEmpty()) {
            Text(text = "No continuity issues detected. All shots are consistent!", color = SuccessGreen, fontSize = 13.sp)
        } else {
            issues.forEach { issue ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = CinematicSurfaceVariant),
                    border = BorderStroke(1.dp, if (issue.severity == "CRITICAL") DangerCrimson else WarningAmber),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "SHOT #${issue.shotNumber} • ${issue.category}",
                                color = if (issue.severity == "CRITICAL") DangerCrimson else WarningAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = issue.severity,
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = issue.description, color = TextPrimary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Suggestion: ${issue.suggestion}",
                            color = CyberCyanSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AiDirectorDialogModal(
    shot: ShotEntity,
    isThinking: Boolean,
    onDismiss: () -> Unit,
    onConsult: (String) -> Unit
) {
    var directiveText by remember { mutableStateOf("") }

    Surface(
        color = Color(0x99000000),
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, CyberCyanSecondary),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clickable(enabled = false) {}
                    .testTag("ai_director_modal")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyanSecondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI DIRECTOR FOR SHOT #${shot.shotNumber}",
                                color = CyberCyanSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Describe how you want to alter the artistic direction, lens, lighting, or emotional tone. Character & location continuity will be automatically preserved.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = directiveText,
                        onValueChange = { directiveText = it },
                        placeholder = { Text("e.g. Make this scene more cinematic and romantic, with soft rain reflections and warm backlight", fontSize = 12.sp, color = TextMuted) },
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyanSecondary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Preset tags
                    Text(text = "Quick Presets:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    val presets = listOf(
                        "Make this scene more cinematic and romantic",
                        "High suspense with dramatic Dutch angle and shadows",
                        "Sci-Fi cyberpunk neon reflections & heavy fog",
                        "Golden hour intimate close-up with shallow depth of field"
                    )
                    presets.forEach { preset ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CinematicSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clickable { directiveText = preset }
                        ) {
                            Text(
                                text = "« $preset »",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onConsult(directiveText) },
                        enabled = !isThinking && directiveText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyanSecondary,
                            contentColor = CinematicBlack
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        if (isThinking) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CinematicBlack, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Director Adjusting Shot...", fontWeight = FontWeight.Bold)
                        } else {
                            Text("Apply Creative Direction", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ImageGeneratorModal(
    shot: ShotEntity,
    isGenerating: Boolean,
    onDismiss: () -> Unit,
    onGenerate: (ImageModelType, String, List<String>) -> Unit
) {
    var selectedModel by remember { mutableStateOf(ImageModelType.NANO_BANANA_2) }
    var selectedResolution by remember { mutableStateOf("4K Cinema") }

    Surface(
        color = Color(0x99000000),
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, GoldAmberPrimary),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clickable(enabled = false) {}
                    .testTag("image_gen_modal")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Movie, contentDescription = null, tint = GoldAmberPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "RENDER SHOT #${shot.shotNumber}",
                                color = GoldAmberPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "GOOGLE AI IMAGE MODEL:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    ImageModelType.values().forEach { model ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedModel == model) GoldAmberContainer else CinematicSurfaceVariant,
                            border = BorderStroke(1.dp, if (selectedModel == model) GoldAmberPrimary else CinematicCardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { selectedModel = model }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = model.badge,
                                        color = if (selectedModel == model) GoldAmberPrimary else TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = model.description, color = TextSecondary, fontSize = 10.sp)
                                }
                                if (selectedModel == model) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = GoldAmberPrimary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "RESOLUTION:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("1K Fast", "2K Master", "4K Cinema").forEach { res ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedResolution == res) GoldAmberContainer else CinematicSurfaceVariant,
                                border = BorderStroke(1.dp, if (selectedResolution == res) GoldAmberPrimary else CinematicCardBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedResolution = res }
                            ) {
                                Text(
                                    text = res,
                                    color = if (selectedResolution == res) GoldAmberPrimary else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { onGenerate(selectedModel, selectedResolution, emptyList()) },
                        enabled = !isGenerating,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldAmberPrimary,
                            contentColor = CinematicBlack
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CinematicBlack, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Rendering Frame...", fontWeight = FontWeight.Bold)
                        } else {
                            Text("Generate Storyboard Frame (2 Credits)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoGeneratorModal(
    shot: ShotEntity,
    isConverting: Boolean,
    onDismiss: () -> Unit,
    onConvert: (VideoModelType, String, CameraMovement) -> Unit
) {
    var selectedModel by remember { mutableStateOf(VideoModelType.VEO_3_1) }
    var selectedMovement by remember { mutableStateOf(shot.cameraMovement) }
    var motionPromptText by remember { mutableStateOf(shot.motionPrompt) }

    Surface(
        color = Color(0x99000000),
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, NeonVioletTertiary),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clickable(enabled = false) {}
                    .testTag("video_gen_modal")
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Videocam, contentDescription = null, tint = NeonVioletTertiary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CONVERT TO AI VIDEO (VEO)",
                                color = NeonVioletTertiary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "VIDEO ENGINE:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))

                    VideoModelType.values().forEach { model ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedModel == model) NeonVioletContainer else CinematicSurfaceVariant,
                            border = BorderStroke(1.dp, if (selectedModel == model) NeonVioletTertiary else CinematicCardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { selectedModel = model }
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = model.badge,
                                        color = if (selectedModel == model) NeonVioletTertiary else TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = model.description, color = TextSecondary, fontSize = 10.sp)
                                }
                                if (selectedModel == model) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = NeonVioletTertiary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "CAMERA MOVEMENT:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(CameraMovement.values().toList()) { move ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedMovement == move) NeonVioletContainer else CinematicSurfaceVariant,
                                border = BorderStroke(1.dp, if (selectedMovement == move) NeonVioletTertiary else CinematicCardBorder),
                                modifier = Modifier.clickable { selectedMovement = move }
                            ) {
                                Text(
                                    text = move.label,
                                    color = if (selectedMovement == move) NeonVioletTertiary else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "MOTION PROMPT:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = motionPromptText,
                        onValueChange = { motionPromptText = it },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonVioletTertiary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onConvert(selectedModel, motionPromptText, selectedMovement) },
                        enabled = !isConverting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonVioletTertiary,
                            contentColor = CinematicBlack
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        if (isConverting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CinematicBlack, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generating Video Clip...", fontWeight = FontWeight.Bold)
                        } else {
                            Text("Convert Frame to Video (8 Credits)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditShotModal(
    shot: ShotEntity,
    onDismiss: () -> Unit,
    onSave: (ShotEntity) -> Unit,
    onDelete: () -> Unit
) {
    var actionPrompt by remember { mutableStateOf(shot.actionPrompt) }
    var dialogueSpeaker by remember { mutableStateOf(shot.dialogueSpeaker) }
    var dialogue by remember { mutableStateOf(shot.dialogue) }
    var sfxNotes by remember { mutableStateOf(shot.sfxNotes) }
    var bgmNotes by remember { mutableStateOf(shot.bgmNotes) }
    var duration by remember { mutableStateOf(shot.durationSeconds) }
    var selectedAngle by remember { mutableStateOf(shot.cameraAngle) }

    Surface(
        color = Color(0x99000000),
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CinematicSurface),
                border = BorderStroke(1.dp, CinematicBorderHigh),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clickable(enabled = false) {}
                    .testTag("edit_shot_modal")
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EDIT SHOT #${shot.shotNumber}",
                            color = GoldAmberPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "ACTION PROMPT:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = actionPrompt,
                        onValueChange = { actionPrompt = it },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAmberPrimary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "DIALOGUE:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = dialogueSpeaker,
                            onValueChange = { dialogueSpeaker = it },
                            placeholder = { Text("Speaker", fontSize = 11.sp, color = TextMuted) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAmberPrimary,
                                unfocusedBorderColor = CinematicCardBorder,
                                focusedContainerColor = CinematicBlack,
                                unfocusedContainerColor = CinematicBlack,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dialogue,
                            onValueChange = { dialogue = it },
                            placeholder = { Text("Line of dialogue", fontSize = 11.sp, color = TextMuted) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAmberPrimary,
                                unfocusedBorderColor = CinematicCardBorder,
                                focusedContainerColor = CinematicBlack,
                                unfocusedContainerColor = CinematicBlack,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(2f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "SFX & MUSIC NOTES:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = sfxNotes,
                        onValueChange = { sfxNotes = it },
                        placeholder = { Text("e.g. Rain falling, thunder rumble", fontSize = 11.sp, color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAmberPrimary,
                            unfocusedBorderColor = CinematicCardBorder,
                            focusedContainerColor = CinematicBlack,
                            unfocusedContainerColor = CinematicBlack,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "DURATION: ${String.format("%.1f", duration)}s", color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = duration,
                        onValueChange = { duration = it },
                        valueRange = 1.0f..10.0f,
                        steps = 18,
                        colors = SliderDefaults.colors(
                            thumbColor = GoldAmberPrimary,
                            activeTrackColor = GoldAmberPrimary,
                            inactiveTrackColor = CinematicCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onDelete,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerCrimson),
                            border = BorderStroke(1.dp, DangerCrimson),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Delete")
                        }

                        Button(
                            onClick = {
                                onSave(
                                    shot.copy(
                                        actionPrompt = actionPrompt,
                                        dialogueSpeaker = dialogueSpeaker,
                                        dialogue = dialogue,
                                        sfxNotes = sfxNotes,
                                        durationSeconds = duration,
                                        cameraAngle = selectedAngle
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldAmberPrimary,
                                contentColor = CinematicBlack
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(2f)
                        ) {
                            Text("Save Changes", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
